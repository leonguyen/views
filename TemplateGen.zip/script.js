document.addEventListener('DOMContentLoaded', () => {
    const templateStringEl = document.getElementById('templateString');
    const pairsList = document.getElementById('pairsList');
    const addPairBtn = document.getElementById('addPairBtn');
    const replaceAllBtn = document.getElementById('replaceAllBtn');
    const outputEl = document.getElementById('output');
    const savedPairsTableEl = document.getElementById('savedPairsTable');
    const STORAGE_KEY = 'templateGen_replacements';
    const CLIPBOARD_KEY = 'clipboard';
    // Load saved pairs from LocalStorage.js
    let pairs = [];
    // Handlebars template for table rows
    const savedPairsTemplateSrc = `
    <table class="table table-sm table-bordered align-middle">
      <thead class="table-light">
        <tr>
          <th>Search string</th>
          <th>Replace string</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
      {{#each pairs}}
        <tr data-id="{{@index}}">
          <td><input type="text" class="form-control form-control-sm searchInp" value="{{this.search}}" /></td>
          <td><textarea class="form-control form-control-sm replaceTxt" rows="2">{{this.replace}}</textarea></td>
          <td><button data-id="{{@index}}" class="btn btn-danger btn-sm delete-row">&times;</button></td>
        </tr>
      {{/each}}
      </tbody>
    </table>
    <small class="text-muted">Edit rows directly above, changes save automatically.</small>
  `;
    const savedPairsTemplate = Handlebars.compile(savedPairsTemplateSrc);
    // Initialize pairs from LocalStorage
    function loadPairs() {
        const stored = LocalStorage.get(ALIAS()) || '[]';
        try {
            pairs = JSON.parse(stored) || [];
        } catch {
            pairs = [];
        }
    }
    // Save pairs to LocalStorage
    function savePairs() {
        //LocalStorage.set(ALIAS(), pairs);
    }
    // Alias for LocalStorage key (match your environment)
    function ALIAS() {
        return STORAGE_KEY;
    }

    function ALIAS_CB() {
        return CLIPBOARD_KEY;
    }
    // Render the editable pairs table
    function renderPairsTable() {
        savedPairsTableEl.innerHTML = savedPairsTemplate({pairs});
        // Add event listeners for Delete buttons
        [...savedPairsTableEl.querySelectorAll('.delete-row')].forEach(btn => {
            btn.addEventListener('click', e => {
                const id = Number(e.currentTarget.dataset.id);
                if (!isNaN(id)) {
                    pairs.splice(id, 1);
                    savePairs();
                    renderPairsTable();
                    renderPairsInputs();
                }
            });
        });
        // Add input listener to update pairs on input change
        [...savedPairsTableEl.querySelectorAll('input.searchInp')].forEach((input, idx) => {
            input.addEventListener('input', e => {
                pairs[idx].search = e.target.value;
                savePairs();
                renderPairsInputs();
            });
        });
        [...savedPairsTableEl.querySelectorAll('textarea.replaceTxt')].forEach((textarea, idx) => {
            textarea.addEventListener('input', e => {
                pairs[idx].replace = e.target.value;
                savePairs();
                renderPairsInputs();
            });
        });
    }
    // Render the pairs inputs area for "Add"/"Remove" UI
    function renderPairsInputs() {
        pairsList.innerHTML = '';
        pairs.forEach((pair, idx) => {
            const div = document.createElement('div');
            div.classList.add('pair-row');
            const searchInput = document.createElement('input');
            searchInput.type = 'text';
            searchInput.placeholder = 'Search string';
            searchInput.value = pair.search || '';
            searchInput.className = "form-control";
            searchInput.addEventListener('input', e => {
                pairs[idx].search = e.target.value;
                savePairs();
                renderPairsTable();
            });
            const replaceTextarea = document.createElement('textarea');
            replaceTextarea.rows = 4;
            replaceTextarea.cols = 8;
            replaceTextarea.placeholder = 'Replace string';
            replaceTextarea.value = pair.replace || '';
            replaceTextarea.className = "form-control";
            replaceTextarea.addEventListener('input', e => {
                pairs[idx].replace = e.target.value;
                savePairs();
                renderPairsTable();
            });
            const removeBtn = document.createElement('button');
            removeBtn.type = 'button';
            removeBtn.className = 'remove-pair-btn';
            removeBtn.innerHTML = '&#10006;';
            removeBtn.title = 'Remove this pair';
            removeBtn.addEventListener('click', () => {
                pairs.splice(idx, 1);
                savePairs();
                renderPairsInputs();
                renderPairsTable();
            });
            div.appendChild(searchInput);
            div.appendChild(replaceTextarea);
            div.appendChild(removeBtn);
            pairsList.appendChild(div);
        });
    }
    // Add new empty pair
    addPairBtn.addEventListener('click', () => {
        pairs.push({
            search: '',
            replace: ''
        });
        savePairs();
        renderPairsInputs();
        renderPairsTable();
    });
    // Replace all pairs in template string
    replaceAllBtn.addEventListener('click', () => {
        let replaced = templateStringEl.value;
        pairs.forEach(({
            search,
            replace
        }) => {
            if (search) {
                // Escape search string for use in RegExp (global, case sensitive)
                const escapedSearch = search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                const re = new RegExp(escapedSearch, 'g');
                replaced = replaced.replace(re, replace);
            }
        });
        // Render output with handlebars and Prism.js escape codes
        const template = Handlebars.compile(`<textarea id="output" class="form-control" rows="5">{{{code}}}</textarea>`);
        // Prism.js also requires html entities escaped
        const htmlEscaped = replaced.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        outputEl.textContent = htmlEscaped;
        Prism.highlightElement(outputEl);
        LocalStorage.set(ALIAS_CB(), replaced);
    });
    // Initial load
    loadPairs();
    renderPairsInputs();
    renderPairsTable();
});
$(document).ready(function() {
    $('#copyButton').clipboard({
        outputText: 'output'
    });
});